package com.spartan.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.pm.ResolveInfo;
import android.widget.TextView;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int VOICE = 41, MIC = 42;
    private LinearLayout chatList;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private boolean ttsReady;
    private Spinner languagePicker;
    private final ArrayList<Locale> speechLanguages = new ArrayList<>();
    private Locale selectedLanguage = Locale.getDefault();

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(0xffffffff);
        getWindow().setNavigationBarColor(0xfff1efff);
        int ui=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; if(android.os.Build.VERSION.SDK_INT>=26)ui|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; getWindow().getDecorView().setSystemUiVisibility(ui);
        buildUi();
        tts = new TextToSpeech(this, this);
        line("Sparten AI", "Hi! Main Sparten AI hoon. Type ya mic se command dein. Main installed apps khol sakta hoon, web search aur timer chala sakta hoon, aur calls/messages tayyar kar sakta hoon.");
    }

    private void buildUi() {
        FrameLayout page = new FrameLayout(this);
        page.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xffffffff, 0xfff1efff}));
        addBlob(page, 0x99A78BFA, 340, Gravity.TOP | Gravity.START, -110, -90, 0, 0);
        addBlob(page, 0x8843C6FF, 320, Gravity.CENTER_VERTICAL | Gravity.END, 0, 0, -150, 0);
        addBlob(page, 0x77FF8FC8, 340, Gravity.BOTTOM | Gravity.START, -120, 0, 0, -120);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(10));

        // Header: 3D orb + title
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), dp(6), dp(4), dp(14));
        View orb = new View(this);
        GradientDrawable og = new GradientDrawable();
        og.setShape(GradientDrawable.OVAL);
        og.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        og.setGradientCenter(0.32f, 0.28f);
        og.setGradientRadius(dp(40));
        og.setColors(new int[]{0xffffffff, 0xffc3b5ff, 0xff6c4de6, 0xff3b2a9e});
        orb.setBackground(og);
        orb.setElevation(dp(10));
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            orb.setOutlineAmbientShadowColor(0xff6c4de6);
            orb.setOutlineSpotShadowColor(0xff6c4de6);
        }
        header.addView(orb, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(14), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText("Sparten AI");
        title.setTextSize(26);
        title.setTextColor(0xff1d1836);
        title.setTypeface(null, Typeface.BOLD);
        TextView sub = new TextView(this);
        sub.setText("Voice & text assistant  ·  offline");
        sub.setTextSize(13);
        sub.setTextColor(0xff6f6a85);
        titles.addView(title);
        titles.addView(sub);
        header.addView(titles);
        root.addView(header);

        // Language glass card
        LinearLayout langCard = new LinearLayout(this);
        langCard.setOrientation(LinearLayout.VERTICAL);
        langCard.setPadding(dp(16), dp(10), dp(16), dp(2));
        langCard.setBackground(glass(22, 0xE6FFFFFF, 0x99FFFFFF, 0x66B4A9FF));
        langCard.setElevation(dp(6));
        TextView languageLabel = new TextView(this);
        languageLabel.setText("Voice language / آواز کی زبان");
        languageLabel.setTextSize(12);
        languageLabel.setTextColor(0xff6f6a85);
        langCard.addView(languageLabel);
        languagePicker = new Spinner(this);
        langCard.addView(languagePicker, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams langLp = new LinearLayout.LayoutParams(-1, -2);
        langLp.setMargins(dp(2), 0, dp(2), dp(12));
        root.addView(langCard, langLp);

        // Chat glass card
        scroll = new ScrollView(this);
        scroll.setBackground(glass(26, 0xD9FFFFFF, 0x80FFFFFF, 0x66B4A9FF));
        scroll.setElevation(dp(8));
        scroll.setClipToOutline(true);
        chatList = new LinearLayout(this);
        chatList.setOrientation(LinearLayout.VERTICAL);
        chatList.setPadding(dp(10), dp(12), dp(10), dp(8));
        scroll.addView(chatList, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams chatLp = new LinearLayout.LayoutParams(-1, 0, 1);
        chatLp.setMargins(dp(2), 0, dp(2), dp(12));
        root.addView(scroll, chatLp);

        // Input glass pill
        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Type a command / apna command likhein");
        input.setHintTextColor(0xff8a86a0);
        input.setTextColor(0xff22202a);
        input.setTextSize(16);
        input.setPadding(dp(18), dp(12), dp(18), dp(12));
        input.setBackground(glass(28, 0xF2FFFFFF, 0xCCFFFFFF, 0x66B4A9FF));
        input.setElevation(dp(5));
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(-1, -2);
        inLp.setMargins(dp(2), 0, dp(2), dp(12));
        root.addView(input, inLp);

        // Buttons: glossy 3D Speak + glass Send
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button mic = new Button(this);
        mic.setText("🎙  Speak");
        mic.setAllCaps(false);
        mic.setTextSize(17);
        mic.setTypeface(null, Typeface.BOLD);
        mic.setTextColor(0xffffffff);
        mic.setBackground(glossy(28, 0xff9b87ff, 0xff5a3fe0, 54));
        mic.setStateListAnimator(null);
        mic.setElevation(dp(9));
        Button send = new Button(this);
        send.setText("Send");
        send.setAllCaps(false);
        send.setTextSize(17);
        send.setTypeface(null, Typeface.BOLD);
        send.setTextColor(0xff4b34c9);
        send.setBackground(glass(28, 0xF2FFFFFF, 0xB3F3F0FF, 0x88B4A9FF));
        send.setStateListAnimator(null);
        send.setElevation(dp(6));
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(0, dp(54), 1.3f);
        micLp.setMargins(dp(2), 0, dp(6), 0);
        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        sendLp.setMargins(dp(6), 0, dp(2), 0);
        buttons.addView(mic, micLp);
        buttons.addView(send, sendLp);
        root.addView(buttons);

        TextView note = new TextView(this);
        note.setText("Choose any voice language supported by your phone. Calls need your confirmation.");
        note.setTextSize(12);
        note.setTextColor(0xff7d7893);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(4), dp(10), dp(4), 0);
        root.addView(note);

        page.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(page);
        pressable(mic);
        pressable(send);
        send.setOnClickListener(v -> submit());
        mic.setOnClickListener(v -> startVoice());
        input.setOnEditorActionListener((v, action, event) -> { submit(); return true; });
    }

    private void addBlob(FrameLayout parent, int color, int sizeDp, int gravity, int ml, int mt, int mr, int mb) {
        View v = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(dp(sizeDp / 2));
        g.setColors(new int[]{color, color & 0x00ffffff});
        v.setBackground(g);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), gravity);
        p.setMargins(dp(ml), dp(mt), dp(mr), dp(mb));
        parent.addView(v, p);
    }

    private GradientDrawable glass(int radiusDp, int top, int bottom, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private Drawable glossy(int radiusDp, int c1, int c2, int heightDp) {
        GradientDrawable base = glass(radiusDp, c1, c2, 0x88FFFFFF);
        GradientDrawable gloss = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x77FFFFFF, 0x00FFFFFF});
        gloss.setCornerRadius(dp(radiusDp - 4));
        LayerDrawable ld = new LayerDrawable(new Drawable[]{base, gloss});
        ld.setLayerInset(1, dp(5), dp(3), dp(5), dp(heightDp / 2));
        return ld;
    }

    private void pressable(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
            return false;
        });
    }

    private int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private void submit(){ String s=input.getText().toString().trim(); if(s.isEmpty())return; input.setText(""); line("You",s); handle(s); }
    private void line(String who,String s){
        boolean me=who.equals("You");
        TextView t=new TextView(this); t.setText(s); t.setTextSize(16); t.setTextIsSelectable(true); t.setLineSpacing(dp(2),1f); t.setPadding(dp(14),dp(10),dp(14),dp(10));
        if(me){ t.setTextColor(0xffffffff); t.setBackground(glass(20,0xff9b87ff,0xff5b6cff,0x66FFFFFF)); }
        else { t.setTextColor(0xff22202a); t.setBackground(glass(20,0xF2FFFFFF,0xCCF4F1FF,0x55B4A9FF)); }
        t.setElevation(dp(me?5:3));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2); p.gravity=me?Gravity.END:Gravity.START; p.setMargins(me?dp(48):dp(4),dp(5),me?dp(4):dp(48),dp(7));
        chatList.addView(t,p);
        t.setAlpha(0f); t.setTranslationY(dp(10)); t.animate().alpha(1f).translationY(0f).setDuration(240).start();
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    private void say(String s){ line("Sparten AI",s); if(ttsReady) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"Spartan-reply"); }
    private void startVoice(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC); return; }
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ say("Speech recognition is not available on this phone. Please type your command."); return; }
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,selectedLanguage.toLanguageTag()); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak in your preferred language"); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
        try{startActivityForResult(i,VOICE);}catch(ActivityNotFoundException e){say("Voice recognition service is unavailable. You can type instead.");}
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==MIC&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startVoice();else if(r==MIC)say("Microphone permission is needed for voice input.");}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==VOICE&&c==RESULT_OK&&d!=null){ArrayList<String>a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty()){line("You",a.get(0));handle(a.get(0));}}}

    private void handle(String raw){
        String s=raw.trim(), l=s.toLowerCase(Locale.ROOT);
        String number=extractNumber(s,l);
        if(number!=null){launch(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+number)),"Dialer opened. Please review and place the call yourself.");return;}
        String sms=afterAny(s,l,"message ","sms ","text ","paigham ","پیغام ");
        if(sms!=null){try{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"));i.putExtra("sms_body",sms);launch(i,"Message composer opened. Please check the recipient and send it yourself.");}catch(Exception e){say("Could not open messaging.");}return;}
        if(has(l,"timer","set timer","ٹائمر","timer lagao")){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{1,3})\\s*(min|minute|minutes|mins|sec|second|seconds|سیکنڈ|منٹ)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(l);if(m.find()){int n=Integer.parseInt(m.group(1));String u=m.group(2);int sec=n*(u.startsWith("min")||u.equals("منٹ")?60:1);Intent i=new Intent("android.intent.action.SET_TIMER");i.putExtra("android.intent.extra.LENGTH",sec);i.putExtra("android.intent.extra.MESSAGE","Sparten AI timer");launch(i,"Timer screen opened.");}else say("Tell me a duration, for example: set timer 5 minutes.");return;}
        String q=afterAny(s,l,"search for ","search ","google ","find ","talaash karo ","dhoondo ","تلاش کرو ","ڈھونڈو ");
        if(q!=null&&!q.isEmpty()){try{launch(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+URLEncoder.encode(q,"UTF-8"))),"Search opened in your browser.");}catch(Exception e){say("Could not open search.");}return;}
        String app=getApp(l);
        if(app!=null){openApp(app);return;}
        String requestedApp=afterAny(s,l,"open ","launch ","start ","kholo ","khol do ","چلاؤ ","کھولو ","کھول دو ");
        if(requestedApp==null && l.endsWith(" kholo")) requestedApp=s.substring(0,s.length()-6).trim();
        if(requestedApp==null && l.endsWith(" khol do")) requestedApp=s.substring(0,s.length()-8).trim();
        if(requestedApp!=null && openInstalledApp(requestedApp))return;
        if(has(l,"call","phone uthao","answer call","auto answer","کال اٹھاؤ")){say("Android does not let a regular assistant app automatically answer and speak on a mobile call. I can open the dialer when you ask to call a number.");return;}
        if(has(l,"your name","tumhara naam","aap ka naam","تمہارا نام","آپ کا نام")){say("My name is Sparten AI. Main aapki assistant hoon.");return;}
        if(java.util.regex.Pattern.compile("\\b(hello|hi|hey|salam|assalam|salaam)\\b").matcher(l).find()||has(l,"السلام علیکم","ہیلو")){say("Wa alaikum assalam! Main Sparten AI hoon. Aap kya karwana chahte hain?");return;}
        say("I did not understand that yet. Try: open settings, open YouTube, search weather, call 03001234567, or set timer 5 minutes.");
    }
    private boolean has(String s,String... words){for(String w:words)if(s.contains(w))return true;return false;}
    private String afterAny(String raw,String low,String... starts){for(String x:starts)if(low.startsWith(x))return raw.substring(x.length()).trim();return null;}
    private String extractNumber(String raw,String low){String[] starts={"call ","call karo ","dial ","number milao ","kall karo ","نمبر ملاؤ ","کال کرو "};for(String p:starts)if(low.startsWith(p)){String n=raw.substring(p.length()).replaceAll("[^+0-9]","");return n.length()>=3?n:null;}return null;}
    private String getApp(String l){if(!has(l,"open ","kholo ","khol do ","کھولو","کھول دو") && !l.endsWith(" kholo") && !l.endsWith(" khol do"))return null;
        if(has(l,"settings","setting","سیٹنگ"))return "settings"; if(has(l,"youtube","یوٹیوب"))return "youtube"; if(has(l,"camera","کیمرا","کیمرہ"))return "camera"; if(has(l,"maps","map","نقشہ"))return "maps"; if(has(l,"chrome","browser","کروم"))return "browser"; if(has(l,"whatsapp","واٹس ایپ"))return "whatsapp"; if(has(l,"phone","dialer"))return "dialer"; if(has(l,"clock","گھڑی"))return "clock"; if(has(l,"calculator","calculate","کیلکولیٹر"))return "calculator"; return null;}
    private void openApp(String key){
        if(key.equals("settings")){launch(new Intent(android.provider.Settings.ACTION_SETTINGS),"Settings opened.");return;}
        if(key.equals("camera")){launch(new Intent("android.media.action.IMAGE_CAPTURE"),"Camera opened.");return;}
        if(key.equals("dialer")){launch(new Intent(Intent.ACTION_DIAL),"Dialer opened.");return;}
        if(key.equals("clock")){launch(new Intent("android.intent.action.SHOW_ALARMS"),"Clock opened.");return;}
        String[] candidates;
        switch(key){case "youtube": candidates=new String[]{"com.google.android.youtube"};break;case "maps":candidates=new String[]{"com.google.android.apps.maps"};break;case "browser":candidates=new String[]{"com.android.chrome","org.mozilla.firefox","com.brave.browser"};break;case "whatsapp":candidates=new String[]{"com.whatsapp"};break;default:candidates=new String[]{"com.google.android.calculator","com.android.calculator2"};}
        PackageManager pm=getPackageManager();for(String p:candidates){Intent i=pm.getLaunchIntentForPackage(p);if(i!=null){launch(i,"Opening "+key+".");return;}}say("That app is not installed or its package is different on this phone.");
    }
    private boolean openInstalledApp(String requested){
        Intent query=new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps=getPackageManager().queryIntentActivities(query,0);
        String wanted=normalize(requested);
        Collections.sort(apps,Comparator.comparing(a->String.valueOf(a.loadLabel(getPackageManager())).toLowerCase(Locale.ROOT)));
        for(ResolveInfo info:apps){
            String label=String.valueOf(info.loadLabel(getPackageManager())); String normalized=normalize(label);
            if(normalized.equals(wanted)||normalized.contains(wanted)||wanted.contains(normalized)){
                Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER); i.setClassName(info.activityInfo.packageName,info.activityInfo.name); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                launch(i,"Opening "+label+"."); return true;
            }
        }
        say("I could not find an installed app named "+requested+"."); return true;
    }
    private String normalize(String value){return value.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]","").trim();}
    private void launch(Intent i,String ok){try{startActivity(i);say(ok);}catch(ActivityNotFoundException e){say("No compatible app was found on this phone.");}catch(SecurityException e){say("Android blocked that action. Check this app’s permissions and try again.");}}
    @Override public void onInit(int status){if(status==TextToSpeech.SUCCESS){
        speechLanguages.clear();
        if(android.os.Build.VERSION.SDK_INT>=21){for(Locale locale:tts.getAvailableLanguages())if(locale!=null&&!locale.getLanguage().isEmpty())speechLanguages.add(locale);}
        if(speechLanguages.isEmpty())speechLanguages.add(Locale.getDefault());
        Collections.sort(speechLanguages,Comparator.comparing(Locale::getDisplayName));
        int selected=0; ArrayList<String> names=new ArrayList<>();
        for(int n=0;n<speechLanguages.size();n++){Locale locale=speechLanguages.get(n);names.add(locale.getDisplayName(locale)+" ("+locale.toLanguageTag()+")");if(locale.getLanguage().equals(selectedLanguage.getLanguage()))selected=n;}
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);languagePicker.setAdapter(adapter);languagePicker.setSelection(selected);
        languagePicker.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){selectedLanguage=speechLanguages.get(pos);int result=tts.setLanguage(selectedLanguage);ttsReady=result!=TextToSpeech.LANG_MISSING_DATA&&result!=TextToSpeech.LANG_NOT_SUPPORTED;}});
        int r=tts.setLanguage(selectedLanguage);ttsReady=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;
    }}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
